local node = extends extends "Node2D"

function node:_ready()
	-- Initalization here
    print(self, '_ready')
end

function node:_on_Button_pressed()
	self:get_node("Label"):set_text("GD-LSW : Hello World")
end